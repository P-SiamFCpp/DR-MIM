# -*- coding: utf-8 -*

# -------------------------------------------------------------------------------
# Author: LiuNing
# Contact: 2742229056@qq.com
# Software: PyCharm
# File: config.py
# Time: 6/10/19 6:55 PM
# Description: 
# -------------------------------------------------------------------------------

BATCH_SIZE =6

INPUT_SIZE = (448, 448)  # (w, h)
RESIZE_SIZE = (512, 512)
SAVE_FREQ = 10
TEST_FREQ = 1
RESUME = ''
MIXUP = 0.

SAVE_DIR = './modelnew/'
TOTAL_EPOCH = 250

SEED = 666
version = 'rdpair'
#baseline/rdpair/transf/all


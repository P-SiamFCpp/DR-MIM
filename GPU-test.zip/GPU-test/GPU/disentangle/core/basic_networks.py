import torch.nn as nn


class vgg_layer0(nn.Module):
    def __init__(self, nin, nout):
        super(vgg_layer0, self).__init__()
        self.main = nn.Sequential(
                nn.Conv2d(nin, nout, 3, 1, 1),
                nn.BatchNorm2d(nout),
                # nn.ReLU()
                nn.LeakyReLU(0.2)
                )

    def forward(self, input):
        return self.main(input)

class dcgan_conv0(nn.Module):
    def __init__(self, nin, nout,ksize):
        super(dcgan_conv0, self).__init__()

        self.main = nn.Sequential(
                nn.Conv2d(nin, nout, ksize, 1, 0),
                nn.BatchNorm2d(nout),
                nn.LeakyReLU(0.2),
                )

    def forward(self, input):
        return self.main(input)

##---2021.08.03新增，改动e1e2不同。----------------------
# 主要使用的代码文件是：PaperWork_CUB_DNET-useNorcons_1.py
class dcgan_conv1(nn.Module):
    def __init__(self, nin, nout,ksize):
        super(dcgan_conv1, self).__init__()
        self.mainno = nn.Sequential(
                nn.Conv2d(nin, nout, ksize, 1, 0),
                nn.BatchNorm2d(nout),
                nn.LeakyReLU(0.2),
                )
    def forward(self, input):
        return self.mainno(input)
##----------------------------------------------------

class dcgan_upconv0(nn.Module):
    def __init__(self, nin, nout,ksize):
        super(dcgan_upconv0, self).__init__()
        self.main = nn.Sequential(
                nn.ConvTranspose2d(nin, nout, ksize, 1, 0,),
                nn.BatchNorm2d(nout),
                nn.LeakyReLU(0.2),
                )

    def forward(self, input):
        return self.main(input)


#gait ori-code
# class vgg_layer(nn.Module):
#     def __init__(self, nin, nout):
#         super(vgg_layer, self).__init__()
#         self.main = nn.Sequential(
#                 nn.Conv2d(nin, nout, 3, 1, 1),
#                 nn.BatchNorm2d(nout),
#                 # nn.ReLU()
#                 nn.LeakyReLU(0.2)
#                 )
#
#     def forward(self, input):
#         return self.main(input)
#
# class dcgan_conv(nn.Module):
#     def __init__(self, nin, nout):
#         super(dcgan_conv, self).__init__()
#         self.main = nn.Sequential(
#                 nn.Conv2d(nin, nout, 3, 1, 0),
#                 nn.BatchNorm2d(nout),
#                 nn.LeakyReLU(0.2),
#                 )
#
#     def forward(self, input):
#         return self.main(input)
#
# class dcgan_upconv(nn.Module):
#     def __init__(self, nin, nout):
#         super(dcgan_upconv, self).__init__()
#         self.main = nn.Sequential(
#                 nn.ConvTranspose2d(nin, nout, 3, 2, 0,),
#                 nn.BatchNorm2d(nout),
#                 nn.LeakyReLU(0.2),
#                 )
#
#     def forward(self, input):
#         return self.main(input)


#1:ywx的方法：3×3卷积核，但是不改变大小。
# class vgg_layer1(nn.Module):
#     def __init__(self, nin, nout):
#         super(vgg_layer1, self).__init__()
#         self.main = nn.Sequential(
#                 nn.Conv2d(nin, nout, 3, 1, 1),
#                 nn.BatchNorm2d(nout),
#                 # nn.ReLU()
#                 nn.LeakyReLU(0.2)
#                 )
#
#     def forward(self, input):
#         return self.main(input)
# class dcgan_conv1(nn.Module):
#     def __init__(self, nin, nout,ksize):
#         super(dcgan_conv1, self).__init__()
#
#         self.main = nn.Sequential(
#                 nn.Conv2d(nin, nout, ksize, 1, 1),
#                 nn.BatchNorm2d(nout),
#                 nn.LeakyReLU(0.2),
#                 )
#
#     def forward(self, input):
#         return self.main(input)
#
# class dcgan_upconv1(nn.Module):
#     def __init__(self, nin, nout,ksize):
#         super(dcgan_upconv1, self).__init__()
#         self.main = nn.Sequential(
#                 nn.ConvTranspose2d(nin, nout, ksize, 1, 1),
#                 nn.BatchNorm2d(nout),
#                 nn.LeakyReLU(0.2),
#                 )
#
#     def forward(self, input):
#         return self.main(input)
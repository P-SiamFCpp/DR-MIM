# -*- coding: utf-8 -*

# from core.loss import *
import torchvision.models as models
# from core.seed import init_environment

# from core.basic_networks import *

from disentangle.core.basic_networks import *
from torch import nn
import torch
import numpy as np
from compression_params import *
########################################################################
# DCL
#
# class DCL(nn.Module):
#     def __init__(self, classes=200, stride=2, use_dcl=True):
#         super(DCL, self).__init__()
#         self.classes = classes
#         self.use_dcl = use_dcl
#
#         model = models.resnet50(pretrained=True)
#         if stride == 1:
#             model.layer4[0].downsample[0].stride = (1, 1)
#             model.layer4[0].conv2.stride = (1, 1)
#         model.avgpool = nn.AdaptiveAvgPool2d((1, 1))
#         self.backbone = model
#         self.cls = nn.Linear(2048, classes, bias=False)
#         self.cls1 = nn.Linear(1024, classes, bias=False)
#         self.clsfg = nn.Linear(1024, classes, bias=False)
#         self.classifier_swap = nn.Linear(2048, 2, bias=False)
#
#         self.Convmask = nn.Conv2d(2048, 1, 1, stride=1, padding=0, bias=True)
#         self.avgpool2 = nn.AvgPool2d(2, stride=2)
#
#         self.loss = nn.CrossEntropyLoss()
#         self.l1_loss = nn.L1Loss()
#         self.L2loss = nn.MSELoss()
#         self.softmax = nn.Softmax()
#         self.label = None
#
#     def fix_params(self, is_training=True):
#         for p in self.backbone.parameters():
#             p.requires_grad = is_training
#
#     def get_loss(self, logits, labels, label_swaps, law_swaps):
#         # loss = self.loss(logits[0], labels) + self.loss(logits[1], label_swaps) + self.l1_loss(logits[2], law_swaps)
#         loss = self.loss(logits[0], labels)
#         return loss
#
#     def L2Softmax(self, fg):
#         fg = self.clsfg(fg)
#         out = self.softmax(fg)
#         # print(out.size())
#         self.label = Variable(torch.ones(out.size()).float() * (1 / self.classes), requires_grad=False).cuda()
#         # print(self.label)
#         softloss = self.L2loss(out, self.label)
#         return softloss
#
#     def forward(self, x, label=None):
#         # backbone
#         x = self.backbone.conv1(x)
#         x = self.backbone.bn1(x)
#         x = self.backbone.relu(x)
#         x = self.backbone.maxpool(x)
#         x = self.backbone.layer1(x)
#         x = self.backbone.layer2(x)
#         x = self.backbone.layer3(x)
#         x = self.backbone.layer4(x)
#         #=================================
#
#         x = torch.mean(torch.mean(x, dim=2), dim=2)
#         out = torch.unsqueeze(x, 2)
#         out = torch.unsqueeze(out, 2)
#
#         cls_logits = self.cls(x)
#
#         return [cls_logits, out]


class encoder(nn.Module):
    def __init__(self, num_ch_input, num_ch_id, num_ch_nonid):
        super(encoder, self).__init__()

        # self.fc_zg_p0_nid_mu = nn.Linear(2048, 64)
        # self.fc_zg_p0_nid_lv = nn.Linear(2048, 64)
        # self.nid_pool = nn.AdaptiveMaxPool2d(1)
        # self.opt = opt
        # self.em_dim = em_dim
        # self.fa_dim = fa_dim
        # self.fg_dim = fg_dim
        # nc = 3
        # nf = 64
        # nc = 2048
        # nf = 1024
        # ns = 1024
        ksize=1
        #=====test disentanglement
        # head_width = 256 #self._hyper_params['head_width']
        # head_width_tranf_in = int(head_width * dist_cmprate['backbone_conv5'])
        #=====================
        # num_ch_id = int(head_width_tranf_in/2)
        # num_ch_nonid = head_width_tranf_in - num_ch_id
        self.toId = nn.Sequential(
            dcgan_conv0(num_ch_input, num_ch_id, ksize),
        )
        self.toNonId = nn.Sequential(
            dcgan_conv1(num_ch_input, num_ch_nonid, ksize),
        )

        # self.flatten = nn.Sequential(
        #     nn.BatchNorm1d(self.em_dim),
        # )

    # def reparameterization(self, mu, lv):
    #     std = torch.exp(lv / 2)
    #     sampled_z = torch.cuda.FloatTensor(np.random.normal(0, 1, mu.size()))
    #     return sampled_z * std + mu

    def forward(self, input):
        Id_code = self.toId(input)
        NoneId_code = self.toNonId(input)
        return Id_code, NoneId_code

        # nid_f = self.nid_pool(input).squeeze()
        # fc_zg_p0_nid_mu = self.fc_zg_p0_nid_mu(nid_f)
        # fc_zg_p0_nid_lv = self.fc_zg_p0_nid_lv(nid_f)
        # embeddingnonid = self.reparameterization(fc_zg_p0_nid_mu, fc_zg_p0_nid_lv)
        # #embeddingnonid = self.mainno(input).view(-1,1024*1*1)
        # # embedding = self.flatten(embedding)
        # # fa, fg = torch.split(embedding, [self.fa_dim, self.fg_dim], dim=1)
        # return embedding,embeddingnonid

    def forward0(self, input):
        embedding = self.main(input).view(-1, 1024*1*1)

        nid_f = self.nid_pool(input).squeeze()
        fc_zg_p0_nid_mu = self.fc_zg_p0_nid_mu(nid_f)
        fc_zg_p0_nid_lv = self.fc_zg_p0_nid_lv(nid_f)
        embeddingnonid = self.reparameterization(fc_zg_p0_nid_mu, fc_zg_p0_nid_lv)
        #embeddingnonid = self.mainno(input).view(-1,1024*1*1)
        # embedding = self.flatten(embedding)
        # fa, fg = torch.split(embedding, [self.fa_dim, self.fg_dim], dim=1)
        return embedding,embeddingnonid

class decoder(nn.Module):
    def __init__(self, num_ch_cat, num_ch_recons):
        super(decoder, self).__init__()
        # self.opt = opt
        # nc = 2048
        ksize = 1
        self.num_ch_cat = num_ch_cat
        self.main = nn.Sequential(
            dcgan_upconv0(self.num_ch_cat, num_ch_recons, ksize),
        )

    def forward(self, id_code, nonid_code):
        hidden = torch.cat([id_code, nonid_code], 1)
        # hidden = hidden.unsqueeze(dim=2).unsqueeze(dim=3)
        out = self.main(hidden)
        return out



if __name__ == '__main__':
    # init_environment()

    x = torch.FloatTensor(2, 3, 448, 448)
    net = DCL()
    logits = net(x)

    features = logits[1]

    netE = encoder(em_dim=2048, fa_dim=2000, fg_dim=48)
    out1,out2 = netE(features)
    netD = decoder(em_dim=1088)
    out3 = netD(out1,out2)

    print(logits[0].shape, logits[1].shape)
    print(out1.shape)
    print(out2.shape)
    print(out3.shape)
    #print(out4.shape)

    # print(logits[0].shape)
    # print(logits[1].shape)
    # print(logits[2].shape)

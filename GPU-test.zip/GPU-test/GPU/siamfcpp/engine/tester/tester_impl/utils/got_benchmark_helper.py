# -*- coding: utf-8 -*
import time
from typing import List

# from PIL import Image
import cv2
import numpy as np

from siamfcpp.evaluation.got_benchmark.utils.viz import show_frame
from siamfcpp.pipeline.pipeline_base import PipelineBase
from bin.RTtest import create_trt_fake_quant_127, create_trt_fake_quant_303
from siamfcpp.pipeline.utils import (cxywh2xywh, get_crop,
                                     get_subwindow_tracking,
                                     imarray_to_tensor, tensor_to_numpy,
                                     xywh2cxywh, xyxy2cxywh, imarray)
from tqdm import tqdm


class PipelineTracker(object):
    def __init__(self,
                 name: str,
                 pipeline: PipelineBase,
                 is_deterministic: bool = True):
        """Helper tracker for comptability with 
        
        Parameters
        ----------
        name : str
            [description]
        pipeline : PipelineBase
            [description]
        is_deterministic : bool, optional
            [description], by default False
        """
        self.name = name
        self.is_deterministic = is_deterministic
        self.pipeline = pipeline
    def init(self, image: np.array, box):
        """Initialize pipeline tracker
        
        Parameters
        ----------
        image : np.array
            image of the first frame
        box : np.array or List
            tracking bbox on the first frame
            formate: (x, y, w, h)
        """
        self.pipeline.init(image, box)

    def update(self, image: np.array):
        """Perform tracking
        
        Parameters
        ----------
        image : np.array
            image of the current frame
        
        Returns
        -------
        np.array
            tracking bbox
            formate: (x, y, w, h)
        """
        return self.pipeline.update(image)

    def get_data_127(self, im: np.array, box):
        return self.pipeline.get_data_127(im, box)

    def init_127(self, im, state, data, im_z_crop, avg_chans):
        return self.pipeline.init_127(im, state, data, im_z_crop, avg_chans)

    def get_data_303(self, im):
        return self.pipeline.get_data_303(im)

    def update_303(self, data, im_x_crop, scale_x, target_pos, target_sz, x_size):
        return self.pipeline.update_303(data, im_x_crop, scale_x, target_pos, target_sz, x_size)

    def track(self, img_files: List, box, visualize: bool = False):
        """Perform tracking on a given video sequence
        
        Parameters
        ----------
        img_files : List
            list of image file paths of the sequence
        box : np.array or List
            box of the first frame
        visualize : bool, optional
            Visualize or not on each frame, by default False
        
        Returns
        -------
        [type]
            [description]
        """
        frame_num = len(img_files)
        boxes = np.zeros((frame_num, 4))
        boxes[0] = box
        times = np.zeros(frame_num)
        for f, img_file in enumerate(img_files):
            # print(f)
            # image = Image.open(img_file)
            # if not image.mode == 'RGB':
            #     image = image.convert('RGB')
            image = cv2.imread(img_file, cv2.IMREAD_COLOR)
            data, im_z_crop, avg_chans = self.get_data_127(image, box)
            # if  self._state['state'] = state
            if f > 0:
                data, im_x_crop, scale_x, target_pos_prior, target_sz_prior, x_size=self.get_data_303(image)
            # print(data)
            # return
            start_time = time.time()
            if f == 0:
                # self.init(image, box)
                self.init_127(image, box, data, im_z_crop, avg_chans)

            else:
                # boxes[f, :] = self.update(image)
                boxes[f, :] = self.update_303(data,im_z_crop,scale_x,target_pos_prior,target_sz_prior,x_size)
            times[f] = time.time() - start_time

            # print(times[f])
            # return
            if visualize:
                show_frame(image, boxes[f, :])
        # print(times[0])
        return boxes, times
    # def get_state(self):
    #     return self.pipeline.

# -*- coding: utf-8 -*

import numpy as np
from loguru import logger

import torch
import torch.nn as nn
import torch.nn.functional as F

from siamfcpp.model.common_opr.common_block import (conv_bn_relu,
                                                        xcorr_depthwise)
from siamfcpp.model.module_base import ModuleBase
from siamfcpp.model.task_model.taskmodel_base import (TRACK_TASKMODELS,
                                                          VOS_TASKMODELS)

from compression_params import *

from disentangle.NETWORK_step1_train_baseline_dcl_cat_lt import encoder,decoder

from siamfcpp.model.task_model.taskmodel_impl.loss_functions import DJSLoss
from siamfcpp.model.task_model.taskmodel_impl.statistics_network import (
    LocalStatisticsNetwork,
    GlobalStatisticsNetwork,
)

torch.set_printoptions(precision=8)


@TRACK_TASKMODELS.register
@VOS_TASKMODELS.register
class SiamTrack(ModuleBase):
    r"""
    SiamTrack model for tracking

    Hyper-Parameters
    ----------------
    pretrain_model_path: string
        path to parameter to be loaded into module
    head_width: int
        feature width in head structure
    """

    default_hyper_params = dict(pretrain_model_path="",
                                head_width=256,
                                conv_weight_std=0.01,
                                neck_conv_bias=[True, True, True, True],
                                corr_fea_output=False)

    def __init__(self, backbone, head, loss=None):
        super(SiamTrack, self).__init__()
        self.basemodel = backbone
        self.head = head
        loss['sim'] = nn.MSELoss  ##==========test
        self.loss = loss

        self.num_ch_id = dist_cmprate['num_ch_idcode']
        self.num_ch_nonid = dist_cmprate['num_ch_nonidcode']
        self.coding_size = 6 # 6x6

        self.djs_loss = DJSLoss()
        self.backbone_feature_size = 6 # 6x6
        self.backbone_feature_channels = self.num_ch_id
        self.global_stat_x = GlobalStatisticsNetwork(
            feature_map_size=self.backbone_feature_size,
            feature_map_channels=self.backbone_feature_channels,
            coding_id_channels=self.num_ch_id,
            coding_nonid_channels=self.num_ch_nonid,
            coding_size=self.coding_size,
        )
        self.local_stat_x = LocalStatisticsNetwork(
            img_feature_channels=self.backbone_feature_channels + self.num_ch_id + self.num_ch_nonid
        )

    def apply_Encoder(self, feature):
        # return feature
        # self attention
        # ==========test
        Id_code, NoneId_code = self.netE(feature)
        Idenity_feature = self.identy(feature)
        return Id_code, NoneId_code, Idenity_feature
        # q1 = feature.reshape(feature.shape[0], feature.shape[1], feature.shape[2] * feature.shape[3]).permute(0, 2, 1)  # [batch_size, seq_length, d_model]
        # out = self.seflattn(q1, q1, value=q1)[0]
        # out = q1 + out
        # out = self.norm11(out)
        # feature = out.permute(0, 2, 1).reshape(feature.shape[0], feature.shape[1], feature.shape[2], feature.shape[3])
        # return feature.contiguous()
        # ========================

    def forward(self, *args, phase="train"):
        r"""
        Perform tracking process for different phases (e.g. train / init / track)

        Arguments
        ---------
        target_img: torch.Tensor
            target template image patch
        search_img: torch.Tensor
            search region image patch

        Returns
        -------
        fcos_score_final: torch.Tensor
            predicted score for bboxes, shape=(B, HW, 1)
        fcos_bbox_final: torch.Tensor
            predicted bbox in the crop, shape=(B, HW, 4)
        fcos_cls_prob_final: torch.Tensor
            classification score, shape=(B, HW, 1)
        fcos_ctr_prob_final: torch.Tensor
            center-ness score, shape=(B, HW, 1)
        """
        if phase == 'train':
            # resolve training data
            training_data = args[0]
            target_img = training_data["im_z"]
            # target_img_transpose_neg = target_img.transpose(-1,-2)
            # x_shuffled =  torch.cat([x[1:], x[0].unsqueeze(0)], dim=0)
            target_img_transpose_neg =  torch.cat([target_img[1:], target_img[0].unsqueeze(0)], dim=0)
            # print('target_img:',target_img)
            # print('target_img_transpose_neg:',target_img_transpose_neg)

            target_insearch_img = training_data["im_z1"]  #======test
            search_img = training_data["im_x"]
            # backbone feature
            f_z1 = self.basemodel(target_insearch_img)  #======test
            f_z = self.basemodel(target_img)
            f_z__transpose_neg = self.basemodel(target_img_transpose_neg) #================neg_label
            f_x = self.basemodel(search_img)
            # self attention
            #==========test
            f_z1_id_code, f_z1_nonid_code, Idenity_feature_z1 = self.apply_Encoder(f_z1)
            f_z_id_code, f_z_nonid_code, Idenity_feature_z = self.apply_Encoder(f_z)

            f_z_neg_transpose_id_code, f_z_neg_transpose_nonid_code, Idenity_feature_z_neg_transpose = self.apply_Encoder(f_z__transpose_neg) #================

            # f_z_id_code, f_z_nonid_code, Idenity_feature_z = self.apply_Encoder(f_z)
            f_z_rec = self.netD(f_z_id_code, f_z_nonid_code)
            f_z__transpose_neg_rec = self.netD(f_z_neg_transpose_id_code, f_z_neg_transpose_nonid_code) # ========================
            f_x_id_code, f_x_nonid_code, Idenity_feature_x = self.apply_Encoder(f_x)
            sim_loss = 0
            sim_loss_triplet = 0
            for k in range(0,f_z_id_code.shape[0]):
                # print(sim_loss)
                # input: Tensor,
                # target: Tensor,
                # print('f_z_id_code:',f_z_id_code.shape) # torch.Size([32, 128, 6, 6])
                # print('f_z_id_code[k,:,:,:]:',f_z_id_code[k,:,:,:].shape) # torch.Size([128, 6, 6])
                # print('f_z1_id_code[k,:,:,:]:',f_z1_id_code[k,:,:,:].shape) # torch.Size([128, 6, 6])
                sim_loss += torch.nn.functional.mse_loss(f_z_id_code[k,:,:,:],f_z1_id_code[k,:,:,:].detach())* (1-training_data['is_negative_pair'][k]
                                                                                                                )            # feature adjustment
                # print('\nsim_loss:',sim_loss)
                # anchor: Tensor,positive: Tensor,negative: Tensor,
                # sim_loss_triplet += torch.nn.functional.triplet_margin_loss(f_z1_id_code[k,:,:,:],f_z_id_code[k,:,:,:],f_z_neg_transpose_id_code[k,:,:,:])
                sim_loss_triplet += torch.nn.functional.triplet_margin_loss(f_z_id_code[k,:,:,:],f_z1_id_code[k,:,:,:].detach(),f_z_neg_transpose_id_code[k,:,:,:])
                # print('\nsim_loss_triplet:', sim_loss_triplet)
            rec_loss = torch.nn.functional.mse_loss(f_z, f_z_rec)
            # rec_loss_triplet = torch.nn.functional.triplet_margin_loss(f_z, f_z_rec,f_z__transpose_neg_rec) #===============

            # print('\nrec_loss:',rec_loss)
            # print('\nrec_loss_triplet:',rec_loss_triplet)
            #=======test MI========
            # Get the shared representation and shared features from x and y
            # shared_x, M_x = self.sh_enc_x(x)  # shared_x = linear_layer(M_x)
            # shared_y, M_y = self.sh_enc_y(y)
            # # Shuffle M to create M'
            # M_x_prime = torch.cat([M_x[1:], M_x[0].unsqueeze(0)], dim=0)  # M_x[1:,:,:,:]
            # M_y_prime = torch.cat([M_y[1:], M_y[0].unsqueeze(0)], dim=0)
            #
            x = f_z1
            y = torch.cat([f_z1_id_code,f_z1_nonid_code], dim=1)
            x_shuffled =  torch.cat([x[1:], x[0].unsqueeze(0)], dim=0)

            # Global mutual information estimation
            global_mutual_M_R_x = self.global_stat_x(x, y)  # positive statistic
            global_mutual_M_R_x_prime = self.global_stat_x(x_shuffled, y)
            global_mutual_loss_x = self.djs_loss(
                T=global_mutual_M_R_x,
                T_prime=global_mutual_M_R_x_prime,
            )


            # Local mutual information estimation

            local_mutual_M_R_x = self.local_stat_x(torch.cat([x, y], dim=1))
            local_mutual_M_R_x_prime = self.local_stat_x(torch.cat([x_shuffled, y], dim=1))

            # Compute Local mutual loss

            local_mutual_loss_x = self.djs_loss(
                T=local_mutual_M_R_x,
                T_prime=local_mutual_M_R_x_prime,
            )

            #===========================

            c_z_k = self.c_z_k(f_z_id_code)
            r_z_k = self.r_z_k(f_z_id_code)
            c_x = self.c_x(f_x_id_code)
            r_x = self.r_x(f_x_id_code)
            #========================
            # feature adjustment
            # c_z_k = self.c_z_k(f_z)
            # r_z_k = self.r_z_k(f_z)
            # c_x = self.c_x(f_x)
            # r_x = self.r_x(f_x)
            # feature matching
            r_out = xcorr_depthwise(r_x, r_z_k)
            c_out = xcorr_depthwise(c_x, c_z_k)
            # head
            fcos_cls_score_final, fcos_ctr_score_final, fcos_bbox_final, corr_fea = self.head(
                c_out, r_out)
            predict_data = dict(
                cls_pred=fcos_cls_score_final,
                ctr_pred=fcos_ctr_score_final,
                box_pred=fcos_bbox_final,
            )
            if self._hyper_params["corr_fea_output"]:
                predict_data["corr_fea"] = corr_fea

            # mse loss:
            # sim_loss:tensor(14.25506878, 14 x 0.08=1.12,rec_loss:tensor(1.53269804,
            # global_mutual_loss_x:tensor(1.38751495 1.38 x 0.8=1.104,local_mutual_loss_x:tensor(1.38249516,
            # return predict_data, sim_loss, rec_loss, global_mutual_loss_x, local_mutual_loss_x

            # triplt loss:
            # sim_loss_triplet:tensor(28.45631599,rec_loss_triplet:tensor(1.19326389,
            # global_mutual_loss_x:tensor(1.38751495,local_mutual_loss_x:tensor(1.38249516,
            # return predict_data, sim_loss_triplet, rec_loss, global_mutual_loss_x, local_mutual_loss_x
            return predict_data, sim_loss, rec_loss, global_mutual_loss_x, local_mutual_loss_x
        elif phase == 'feature':
            f_z, = args
            # target_img, = args
            # backbone feature
            # f_z = self.basemodel(target_img)
            # self attention
            # ==========test
            # f_z = self.apply_selfattn(f_z)
            f_z_id_code, f_z_nonid_code, Idenity_feature_z = self.apply_Encoder(f_z)
            # f_z_id_code =
            # template as kernel
            c_z_k = self.c_z_k(f_z_id_code)
            r_z_k = self.r_z_k(f_z_id_code)
            # ========================
            # template as kernel
            # c_z_k = self.c_z_k(f_z)
            # r_z_k = self.r_z_k(f_z)
            # output
            out_list = [c_z_k, r_z_k]

        elif phase == 'track':
            if len(args) == 3:
                f_x, c_z_k, r_z_k = args
                # backbone feature
                # f_x = self.basemodel(search_img)
                # self attention
                # ==========test
                # f_x = self.apply_selfattn(f_x)
                f_x_id_code, f_x_nonid_code, Idenity_feature_x = self.apply_Encoder(f_x)
                # feature adjustment
                c_x = self.c_x(f_x_id_code)
                r_x = self.r_x(f_x_id_code)
                # ========================
                # feature adjustment
                # c_x = self.c_x(f_x)
                # r_x = self.r_x(f_x)
            elif len(args) == 4:
                # c_x, r_x already computed
                c_z_k, r_z_k, c_x, r_x = args
            else:
                raise ValueError("Illegal args length: %d" % len(args))

            # feature matching
            r_out = xcorr_depthwise(r_x, r_z_k)
            c_out = xcorr_depthwise(c_x, c_z_k)
            # head
            fcos_cls_score_final, fcos_ctr_score_final, fcos_bbox_final, corr_fea = self.head(
                c_out, r_out)
            # apply sigmoid
            fcos_cls_prob_final = torch.sigmoid(fcos_cls_score_final)
            fcos_ctr_prob_final = torch.sigmoid(fcos_ctr_score_final)
            # apply centerness correction
            fcos_score_final = fcos_cls_prob_final * fcos_ctr_prob_final
            # register extra output
            extra = dict(c_x=c_x, r_x=r_x, corr_fea=corr_fea)
            # output
            out_list = fcos_score_final, fcos_bbox_final, fcos_cls_prob_final, fcos_ctr_prob_final, extra
        else:
            raise ValueError("Phase non-implemented.")

        return out_list

    def update_params(self):
        r"""
        Load model parameters
        """
        self._make_convs()
        self._initialize_conv()
        super().update_params()

    def _make_convs(self):
        head_width = self._hyper_params['head_width']

        head_width_tranf_in = int(head_width * dist_cmprate['backbone_conv5'])
        head_width_tranf_cls_out = int(head_width * dist_cmprate['tranf_c_x'])
        head_width_tranf_reg_out = int(head_width * dist_cmprate['tranf_r_x'])


        # disentanglement
        #===============test=====
        # nhead = 2
        # d_model = head_width_tranf_in
        # self.seflattn = nn.MultiheadAttention(d_model, nhead, dropout=False)
        # self.norm11 = nn.LayerNorm(d_model)

        head_width = 256  # self._hyper_params['head_width']
        head_width_tranf_in = int(head_width * dist_cmprate['backbone_conv5'])

        # num_ch_id = int(head_width_tranf_in / 2)
        # num_ch_nonid = head_width_tranf_in - num_ch_id
        # num_ch_id = dist_cmprate['num_ch_idcode']
        # num_ch_nonid = dist_cmprate['num_ch_nonidcode']
        num_ch_id = self.num_ch_id
        num_ch_nonid = self.num_ch_nonid
        self.netE = encoder(num_ch_input = head_width_tranf_in, num_ch_id = num_ch_id, num_ch_nonid = num_ch_nonid)
        self.netD = decoder(num_ch_id + num_ch_nonid, head_width_tranf_in)  #num_ch_cat, num_ch_recons
        self.identy = conv_bn_relu(head_width_tranf_in,
                                  num_ch_id,
                                   stride=1,
                                   kszie=3,
                                   pad=0,
                                  has_relu=False)
        #=================================
        head_width_tranf_in = dist_cmprate['num_ch_idcode']
        # feature adjustment
        self.r_z_k = conv_bn_relu(head_width_tranf_in,
                                  head_width_tranf_reg_out,
                                  1,
                                  3,
                                  0,
                                  has_relu=False)
        self.c_z_k = conv_bn_relu(head_width_tranf_in,
                                  head_width_tranf_cls_out,
                                  1,
                                  3,
                                  0,
                                  has_relu=False)
        self.r_x = conv_bn_relu(head_width_tranf_in, head_width_tranf_reg_out, 1, 3, 0, has_relu=False)
        self.c_x = conv_bn_relu(head_width_tranf_in, head_width_tranf_cls_out, 1, 3, 0, has_relu=False)

    def _initialize_conv(self, ):
        conv_weight_std = self._hyper_params['conv_weight_std']
        conv_list = [
            self.r_z_k.conv, self.c_z_k.conv, self.r_x.conv, self.c_x.conv
        ]
        for ith in range(len(conv_list)):
            conv = conv_list[ith]
            torch.nn.init.normal_(conv.weight,
                                  std=conv_weight_std)  # conv_weight_std=0.01
        #=========self attention
        a=0
        for p in self.netE.parameters():
            if p.dim() > 1:
                nn.init.xavier_normal_(p)
        for p in self.netD.parameters():
            if p.dim() > 1:
                nn.init.xavier_normal_(p)
        #=========================

    def set_device(self, dev):
        if not isinstance(dev, torch.device):
            dev = torch.device(dev)
        self.to(dev)
        if self.loss is not None:
            for loss_name in self.loss:
                if loss_name =='sim':
                    continue
                self.loss[loss_name].to(dev)

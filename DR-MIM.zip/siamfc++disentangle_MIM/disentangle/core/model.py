# -*- coding: utf-8 -*

# -------------------------------------------------------------------------------
# Author: LiuNing
# Contact: 2742229056@qq.com
# Software: PyCharm
# File: model.py
# Time: 6/26/19 6:57 PM
# Description: 
# -------------------------------------------------------------------------------

from core.loss import *
# import torchvision.models as models
from block.resnet import resnet50
from core.seed import init_environment

from core.basic_networks import *


########################################################################
# DCL
#
class DCL(nn.Module):
    def __init__(self, classes=200, stride=2, use_dcl=True):
        super(DCL, self).__init__()
        self.classes = classes
        self.use_dcl = use_dcl

        model = resnet50(pretrained=True)
        if stride == 1:
            model.layer4[0].downsample[0].stride = (1, 1)
            model.layer4[0].conv2.stride = (1, 1)
        model.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.backbone = model
        # self.fc7 = nn.Sequential(
        #     nn.Linear(2048, 512),
        #     nn.BatchNorm1d(512),
        #     nn.Dropout(0.5),
        # )
        #2048 x 14 x 14
        #====================by shuiwang
        # outputsize =（inputsize - 1）*stride + output_padding - 2 * padding + kernel_size
        # self.upsamplelayer1 = nn.ConvTranspose2d(2048,2048,kernel_size=3,stride=1,padding=0,output_padding=0)
        # # 2048 x 16 x 16
        # self.upsamplelayer2 = nn.ConvTranspose2d(2048, 1024, kernel_size=4, stride=2, padding=1, output_padding=0)
        # #512 x 32 x 32
        # self.upsamplelayer3 = nn.ConvTranspose2d(1024, 1024, kernel_size=4, stride=2, padding=1, output_padding=0)
        # #128 x 64 x 64
        self.upsamplelayer4 = nn.Upsample(scale_factor=4)
        # self.encoder = encoder(em_dim=512,fa_dim=256, fg_dim=256)
        # self.decoder = decoder(em_dim=512)
        #=========================================

        self.cls = nn.Linear(2048, classes, bias=False)
        self.cls1 = nn.Linear(2000, classes, bias=False)
        self.clsfg = nn.Linear(48,classes,bias=False)
        self.classifier_swap = nn.Linear(2048, 2, bias=False)

        self.Convmask = nn.Conv2d(2048, 1, 1, stride=1, padding=0, bias=True)
        self.avgpool2 = nn.AvgPool2d(2, stride=2)

        self.loss = nn.CrossEntropyLoss()
        self.l1_loss = nn.L1Loss()
        self.L2loss = nn.MSELoss()
        self.softmax = nn.Softmax()
        self.label = None

    def fix_params(self, is_training=True):
        for p in self.backbone.parameters():
            p.requires_grad = is_training

    def get_loss(self, logits, labels, label_swaps, law_swaps):
        # loss = self.loss(logits[0], labels) + self.loss(logits[1], label_swaps) + self.l1_loss(logits[2], law_swaps)
        loss = self.loss(logits[0], labels)
        return loss

    def L2Softmax(self,fg):
        fg = self.clsfg(fg)
        out = self.softmax(fg)
        # print(out.size())
        self.label = Variable(torch.ones(out.size()).float() * (1 / self.classes), requires_grad=False).cuda()
        # print(self.label)
        softloss = self.L2loss(out, self.label)
        return softloss


    def features(self, x):
        # backbone
        x = self.backbone.conv1(x)
        x = self.backbone.bn1(x)
        x = self.backbone.relu(x)
        x = self.backbone.maxpool(x)
        x = self.backbone.layer1(x)
        x = self.backbone.layer2(x)
        x = self.backbone.layer3(x)
        x = self.backbone.layer4(x)

        # x = torch.mean(torch.mean(x, dim=2), dim=2)
        # x = self.cls(x)

        return [x, ]

    def forward(self, x, label=None):
        # backbone
        x = self.backbone.conv1(x)
        x = self.backbone.bn1(x)
        x = self.backbone.relu(x)
        x = self.backbone.maxpool(x)
        x = self.backbone.layer1(x)
        x = self.backbone.layer2(x)
        x = self.backbone.layer3(x)
        x = self.backbone.layer4(x)


        # construct
        mask = self.Convmask(x)
        mask = self.avgpool2(mask)
        mask = torch.tanh(mask)
        mask = mask.view(mask.size(0), -1)


        #==========by shuiwang
        # x = self.upsamplelayer1(x)
        # x = self.upsamplelayer2(x)
        # x = self.upsamplelayer3(x)
        # x = self.upsamplelayer4(x)
        # y = self.encoder(x)
        # y1 = self.decoder(y)
        ft = x
        #=================================

        x = torch.mean(torch.mean(x, dim=2), dim=2)

        # swap classification
        swap_logits = self.classifier_swap(x)

        # bird classification
        cls_logits = self.cls(x)

        return [cls_logits, swap_logits, mask, ft]

class encoder(nn.Module):
    def __init__(self, em_dim, fa_dim, fg_dim):
        super(encoder, self).__init__()
        # self.opt = opt
        self.em_dim = em_dim
        self.fa_dim = fa_dim
        self.fg_dim = fg_dim
        nc = 2048
        nf = 1024
        self.main = nn.Sequential(
            nn.AdaptiveAvgPool2d((7, 7)),
            nn.AdaptiveAvgPool2d((1, 1)),
        )
        self.flatten = nn.Sequential(
            nn.BatchNorm1d(self.em_dim),
        )
    def forward(self, input):
        embedding = self.main(input).view(-1, 2048*1*1)
        fa, fg = torch.split(embedding, [self.fa_dim, self.fg_dim], dim=1)
        return fa, fg
class decoder(nn.Module):
    def __init__(self, em_dim):
        super(decoder, self).__init__()
        nc = 2048
        nf = 1024
        self.em_dim = em_dim

        self.trans = nn.Sequential(
            nn.Linear(self.em_dim, 1024*12*12),
            nn.BatchNorm1d(1024*12*12),
        )

        self.main = nn.Sequential(
            nn.AdaptiveAvgPool2d((3, 3)),
            nn.AdaptiveAvgPool2d((14, 14)),
        )
    def forward(self, fa, fg):
        hidden = torch.cat([fa, fg], 1).view(-1, self.em_dim)
        # small = self.trans(hidden).view(-1, 1024, 12, 12)
        hidden = torch.unsqueeze(hidden,2)
        hidden = torch.unsqueeze(hidden, 2)
        img = self.main(hidden)
        return img



if __name__ == '__main__':
    init_environment()

    x = torch.FloatTensor(2, 3, 448, 448)
    net = DCL()
    logits = net(x)

    print(logits[0].shape)
    print(logits[1].shape)
    print(logits[2].shape)

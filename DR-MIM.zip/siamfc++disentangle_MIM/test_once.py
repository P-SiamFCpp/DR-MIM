import argparse
import os.path as osp
import pickle
import os
import torch

from loguru import logger

def test_once(model, model_path):
    from siamfcpp.config.config import cfg as root_cfg
    from siamfcpp.config.config import specify_task  # sot or vos
    from siamfcpp.engine.builder import build as tester_builder
    from siamfcpp.model import builder as model_builder
    from siamfcpp.pipeline import builder as pipeline_builder
    from siamfcpp.utils import complete_path_wt_root_in_cfg
    # model = 3
    if model == 1:
        config = '/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/models/siamfcpp/test/vot/siamfcpp_alexnet.yaml'  # VOT
    if model == 2:
        config = 'models/siamfcpp/test/otb/siamfcpp_alexnet-otb.yaml'  # OTB
    if model == 3:
        config = '/home/lsw/LSW/siamfc++disentangle_MIM/models/siamfcpp/test/dtb70/siamfcpp_alexnet-dtb70.yaml'  # DTB
    if model == 4:
        config = '/home/lsw/LSW/siamfc++disentangle_MIM/models/siamfcpp/test/uav123/siamfcpp_alexnet-uav123.yaml'  # UAV123
    if model == 5:
        config = '/home/lsw/LSW/siamfc++disentangle_MIM/models/siamfcpp/test/uav20l/siamfcpp_alexnet-uav20l.yaml'  # UAV20L
    if model == 6:
        config = '/home/lsw/LSW/siamfc++disentangle_MIM/models/siamfcpp/test/uavdt/siamfcpp_alexnet-uavdt.yaml'  # UAVDT
    if model == 7:
        config = '/home/lsw/LSW/siamfc++disentangle_MIM/models/siamfcpp/test/visdrone/siamfcpp_alexnet-visdrone2019.yaml'  # visdrone
    if model == 8:
        config = '/home/lsw/LSW/siamfc++disentangle_MIM/models/siamfcpp/test/uav123@10fps/siamfcpp_alexnet-uav123@10fps.yaml'  # UAV123
    if model == 9:
        config = '/home/lsw/LSW/siamfc++disentangle_MIM/models/siamfcpp/test/visdrone/siamfcpp_alexnet-visdrone2018.yaml'  # visdrone2018

    # parsing
    # parser = make_parser()
    parser = argparse.ArgumentParser(description='Test')
    parser.add_argument('-cfg', '--config', default=config, type=str, help='experiment configuration')
    parser.add_argument('-model_path', '--model_path',
                        default='/home/lsw/model-compression/myCMP-rank/rank_evo/siamfc_rank+evo/models/snapshots/siamfcpp_alexnet-got/epoch-15.pkl',
                        type=str, help='experiment configuration')  # 为空则选择yaml里面默认的模型
    parsed_args = parser.parse_args()

    args = parser.parse_args()
    args.model_path = model_path
    # experiment config  #abspath 绝对路径

    exp_cfg_path = os.path.realpath(parsed_args.config)

    root_cfg.merge_from_file(exp_cfg_path)

    # print(root_cfg.test.track.model.task_model.SiamTrack.pretrain_model_path)

    if args.model_path:
        root_cfg.test.track.model.task_model.SiamTrack.pretrain_model_path = args.model_path

        # print(root_cfg.test.track.model.task_model.SiamTrack.pretrain_model_path)

    logger.info("Load experiment configuration at: %s" % exp_cfg_path)
    ROOT_PATH = os.getcwd()
    ROOT_PATH = '/'

    root_cfg = complete_path_wt_root_in_cfg(root_cfg, ROOT_PATH)  # 把cfg中的相对路径,变成了绝对路径

    root_cfg = root_cfg.test  # 获取test的yaml root_cfg['test']
    # root_cfg['track']
    # root_cfg['vos']
    task, task_cfg = specify_task(root_cfg)  # 获取任务 track or vos ,

    task_cfg.freeze()

    torch.multiprocessing.set_start_method('spawn', force=True)

    # build_siamfcpp_tester
    model = model_builder.build("track", task_cfg.model)
    # build pipeline
    pipeline = pipeline_builder.build("track", task_cfg.pipeline, model)  # 配置超参数
    # build tester
    testers = tester_builder("track", task_cfg.tester, "tester", pipeline)

    for tester in testers:
        test_result_dict = tester.test()
    print('finished')
    # precision_score = test_result_dict['main_performance']['precision_score']
    # success_score = test_result_dict['main_performance']['success_score']
    # speed_fps = test_result_dict['main_performance']['speed_fps']
    task_cfg.defrost()
    # return precision_score, success_score, speed_fps


# print('=================epoch 13==============')
# test_once(3,'/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/bin/models/snapshots/siamfcpp_alexnet-got/epoch-13.pkl')
# test_once(6,'/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/bin/models/snapshots/siamfcpp_alexnet-got/epoch-13.pkl')
# test_once(8,'/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/bin/models/snapshots/siamfcpp_alexnet-got/epoch-13.pkl')
# test_once(9,'/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/bin/models/snapshots/siamfcpp_alexnet-got/epoch-13.pkl')
#
# print('=================epoch 14==============')
# test_once(3,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/复现sim-loss=0.08/siamfcpp_alexnet-got/epoch-14.pkl')
# test_once(6,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/复现sim-loss=0.08/siamfcpp_alexnet-got/epoch-14.pkl')
# test_once(8,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/复现sim-loss=0.08/siamfcpp_alexnet-got/epoch-14.pkl')
# test_once(9,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/复现sim-loss=0.08/siamfcpp_alexnet-got/epoch-14.pkl')
# 
# print('=================epoch 15==============')
# test_once(3,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/复现sim-loss=0.08/siamfcpp_alexnet-got/epoch-15.pkl')
# test_once(6,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/复现sim-loss=0.08/siamfcpp_alexnet-got/epoch-15.pkl')
# test_once(8,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/复现sim-loss=0.08/siamfcpp_alexnet-got/epoch-15.pkl')
# test_once(9,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/复现sim-loss=0.08/siamfcpp_alexnet-got/epoch-15.pkl')
# 
# print('=================epoch16==============')
# test_once(3,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/复现sim-loss=0.08/siamfcpp_alexnet-got/epoch-16.pkl')
# test_once(6,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/复现sim-loss=0.08/siamfcpp_alexnet-got/epoch-16.pkl')
# test_once(8, '/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/复现sim-loss=0.08/siamfcpp_alexnet-got/epoch-16.pkl')
# test_once(9, '/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/复现sim-loss=0.08/siamfcpp_alexnet-got/epoch-16.pkl')


print('=================epoch17==============')
test_once(3,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-17.pkl')
test_once(6,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-17.pkl')
test_once(8,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-17.pkl')
test_once(9,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-17.pkl')

print('=================epoch18==============')
test_once(3,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-18.pkl')
test_once(6,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-18.pkl')
test_once(8,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-18.pkl')
test_once(9,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-18.pkl')

print('=================epoch19==============')
test_once(3,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-19.pkl')
test_once(6,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-19.pkl')
test_once(8,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-19.pkl')
test_once(9,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-19.pkl')



# print('=================0.7==============')
# test_once(3,'/home/lsw/LSW/wxc/0.6/epoch-16.pkl')
# test_once(6,'/home/lsw/LSW/wxc/0.6/epoch-16.pkl')
# test_once(8,'/home/lsw/LSW/wxc/0.6/epoch-16.pkl')
# test_once(9,'/home/lsw/LSW/wxc/0.6/epoch-16.pkl')
# 
# print('=================0.6==============')
# test_once(3,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-17.pkl')
# test_once(6,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-17.pkl')
# test_once(8,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-17.pkl')
# test_once(9,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-17.pkl')
# 
# print('=================0.6==============')
# test_once(3,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-18.pkl')
# test_once(6,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-18.pkl')
# test_once(8,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-18.pkl')
# test_once(9,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-18.pkl')
# 
# print('=================0.6==============')
# test_once(3,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-19.pkl')
# test_once(6,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-19.pkl')
# test_once(8,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-19.pkl')
# test_once(9,'/home/lsw/LSW/siamfc++disentangle_MIM/my-test-result/siamfcpp_alexnet-got-005-005-005/epoch-19.pkl')

#
# print('=================epoch 18==============')
# test_once(3,'/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/bin/models/snapshots/siamfcpp_alexnet-got/epoch-18.pkl')
# test_once(6,'/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/bin/models/snapshots/siamfcpp_alexnet-got/epoch-18.pkl')
# test_once(8,'/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/bin/models/snapshots/siamfcpp_alexnet-got/epoch-18.pkl')
# test_once(9,'/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/bin/models/snapshots/siamfcpp_alexnet-got/epoch-18.pkl')
#
# print('=================epoch 19==============')
# test_once(3,'/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/bin/models/snapshots/siamfcpp_alexnet-got/epoch-19.pkl')
# test_once(6,'/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/bin/models/snapshots/siamfcpp_alexnet-got/epoch-19.pkl')
# test_once(8,'/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/bin/models/snapshots/siamfcpp_alexnet-got/epoch-19.pkl')
# test_once(9,'/home/lsw/LSW/siamfc++disentangle_MIM/siamfc++disentangle_MIM/bin/models/snapshots/siamfcpp_alexnet-got/epoch-19.pkl')




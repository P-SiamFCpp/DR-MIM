import numpy as np
# ranks_path = '/home/lsw/model-compression/FisherInfo/SiamFCpp-video_analyst_cmp_Fisher/rank_conv/ranks_avg_fisher.npy'
# dist_ranks_avg = np.load(ranks_path, allow_pickle=True).item()

ranks_path = '/home/lsw/LSW/siamfc++disentangle_MIM/rank_conv/ranks_avg.npy'
dist_ranks_avg = np.load(ranks_path, allow_pickle=True).item()

dist_ranks_thred ={
    'feature_result_conv1': 20,
    'feature_result_conv2': 10,
    'feature_result_conv3': 8,
    'feature_result_conv4': 2,
    'feature_result_conv5': 15,
    'feature_result_c_x': 24,
    'feature_result_r_x': 24,
    'feature_result_bbox_p5_conv1': 15,
    'feature_result_bbox_p5_conv2': 0.000001,
    'feature_result_bbox_p5_conv3': 14,
    'feature_result_cls_p5_conv1': 15,
    'feature_result_cls_p5_conv2': 0.000001,
    'feature_result_cls_p5_conv3': 14,
}
# for conv in dist_ranks_avg:
#     if conv == 'feature_result_cls_p5_conv3':
#         print(conv)
#     print(conv)
#     print(dist_ranks_avg[conv].shape)
#     print(dist_ranks_avg[conv])
#     print((dist_ranks_avg[conv] < 10).sum())


# dist_cmprate = {
# 'backbone_conv1': 0.8,
# 'backbone_conv2': 0.8,
# 'backbone_conv3': 0.8,
# 'backbone_conv4': 0.8,
# 'backbone_conv5': 0.8,
#
# 'tranf_c_x': 0.8,
# 'tranf_r_x': 0.8,
# 'tranf_c_z_k': 0.8, # has to equal tranf_c_x
# 'tranf_r_z_k': 0.8, # has to equal tranf_r_x
#
# 'head_bbox_conv3x3_1': 0.8,
# 'head_bbox_conv3x3_2': 0.8,
# 'head_bbox_conv3x3_3': 0.8,
#
# 'head_cls_conv3x3_1': 0.8,
# 'head_cls_conv3x3_2': 0.8,
# 'head_cls_conv3x3_3': 0.8,
# }



dist_cmprate = {
'backbone_conv1': 0.5,
'backbone_conv2': 0.5,
'backbone_conv3': 0.5,
'backbone_conv4': 0.5,
'backbone_conv5': 0.5,

'num_ch_idcode':    int(256*0.5),
'num_ch_nonidcode': int(256*0.5),

'tranf_c_x':   0.5,
'tranf_r_x':   0.5,
'tranf_c_z_k': 0.5, # has to equal tranf_c_x
'tranf_r_z_k': 0.5, # has to equal tranf_r_x

'head_bbox_conv3x3_1': 0.5,
'head_bbox_conv3x3_2': 0.5,
'head_bbox_conv3x3_3': 0.5,
'head_cls_conv3x3_1':  0.5,
'head_cls_conv3x3_2':  0.5,
'head_cls_conv3x3_3':  0.5,
}